#!/bin/bash
echo "📦 创建聚合支付项目..."
cd /storage/emulated/0/Download/3
mkdir -p pay-agg-demo/views pay-agg-demo/public/css pay-agg-demo/public/js pay-agg-demo/public/images
cd pay-agg-demo
cat > package.json << 'EOF'
{
  "name": "pay-agg-demo",
  "version": "1.0.0",
  "description": "聚合支付一码多付 - 支持支付宝/微信自动识别",
  "type": "module",
  "scripts": {
    "start": "node server.js",
    "dev": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "qrcode": "^1.5.3",
    "alipay-sdk": "^3.3.0",
    "dotenv": "^16.3.1",
    "cors": "^2.8.5",
    "morgan": "^1.10.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
EOF
cat > .env.example << 'EOF'
ALIPAY_APP_ID=你的APP_ID
ALIPAY_PRIVATE_KEY=你的应用私钥（一行格式，去掉换行）
ALIPAY_PUBLIC_KEY=支付宝公钥（一行格式，去掉换行）
WECHAT_MCH_ID=你的商户号
WECHAT_API_KEY=你的API密钥
WECHAT_APP_ID=你的微信APP_ID
PORT=3000
NODE_ENV=production
EOF
echo "✅ 基础文件创建完成"
echo "📥 接下来执行: npm install"
