# 💰 聚合收款 - 一码多付

支持支付宝/微信自动识别的聚合支付服务，同时完美适配移动端和电脑端。

## ✨ 特性

- 🔵 **支付宝** - 自动识别支付宝客户端，生成预创建订单二维码
- 🟢 **微信支付** - 自动识别微信客户端，生成Native支付二维码
- 📱 **移动端优化** - PWA支持，可添加到手机桌面，像原生App一样使用
- 💻 **电脑端支持** - 响应式设计，桌面端同样流畅
- 🔄 **智能识别** - 根据User-Agent自动判断客户端类型
- ⏱️ **实时状态** - 订单状态轮询，支付成功即时反馈
- 🔒 **安全可靠** - 环境变量管理密钥，不暴露敏感信息

## 📁 项目结构

```
pay-agg-demo/
├── server.js          # Express 服务端
├── alipay.js          # 支付宝 SDK 封装
├── wechat.js          # 微信支付封装（示例框架）
├── package.json       # 依赖配置
├── .env.example       # 环境变量模板
├── deploy.sh          # 一键部署脚本
├── views/
│   └── index.html     # 首页（收款创建页）
└── public/
    ├── css/
    │   └── style.css  # 响应式样式
    ├── js/
    │   └── app.js     # 前端交互逻辑
    ├── manifest.json  # PWA 配置
    └── sw.js          # Service Worker
```

## 🚀 快速开始

```bash
cd pay-agg-demo
npm install

# 配置环境变量
cp .env.example .env
# 编辑 .env 填入你的支付宝密钥

npm start
```

访问 `http://localhost:3000` 即可使用。

## 🔧 API 接口

```bash
# 聚合支付入口（自动识别客户端）
GET /pay?amount=9.99&subject=商品名称

# 创建订单（JSON API）
POST /api/order
Body: {"amount":"9.99","subject":"测试","platform":"alipay|wechat|both"}

# 查询订单状态
GET /api/order/{orderNo}/status

# 支付宝异步通知
POST /notify/alipay
```

## 📱 使用方式

| 场景 | 效果 |
|------|------|
| 手机支付宝扫码 | 自动识别，直接显示支付宝收款二维码 |
| 手机微信扫码 | 自动识别，显示微信支付二维码 |
| 手机浏览器访问 | 显示聚合码页面，可切换支付宝/微信Tab |
| 电脑浏览器访问 | 居中卡片布局，输入金额生成聚合码 |
| 添加到桌面 | 像原生App一样全屏运行 |

## License

MIT
